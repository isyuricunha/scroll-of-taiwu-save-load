# scroll-of-taiwu-save-load
 No jogo, você pode salvar manualmente e carregar rapidamente.
